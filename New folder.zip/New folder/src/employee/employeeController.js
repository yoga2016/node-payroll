var employeeService = require("./employeeService");

var getDataConntrollerfn = async (req, res) => {
  var empolyee = await employeeService.getDataFromDBService();
  res.send({ status: true, data: empolyee });
};

var createEmployeeControllerFn = async (req, res) => {
  var status = await employeeService.createEmployeeDBService(req.body);
  if (status) {
    res.send({ status: true, message: "employee created successfully" });
  } else {
    res.send({ status: false, message: "Error creating employee" });
  }
};

var updateEmployeeController = async (req, res) => {
  console.log(req.params.id);
  console.log(req.body);

  var result = await userService.updateEmployeeDBService(
    req.params.id,
    req.body
  );
  if (result) {
    res.send({ status: true, message: "User Updateeeedddddd" });
  } else {
    res.send({ status: false, message: "User Updateeeedddddd Faileddddddd" });
  }
};
var deleteEmployeeController = async (req, res) => {
  console.log(req.params.id);
  var result = await userService.removeEmployeeDBService(req.params.id);
  if (result) {
    res.send({ status: true, message: "User Deleteddd" });
  } else {
    res.send({ status: false, message: "User Deleteddd Faileddddddd" });
  }
};
module.exports = {
  getDataConntrollerfn,
  createEmployeeControllerFn,
  updateEmployeeController,
  deleteEmployeeController,
};
