var employeeModel = require("./employeeModel");
module.exports.getDataFromDBService = () => {
  return new Promise(function checkURL(resolve, reject) {
    employeeModel.find({}, function returnData(error, result) {
      if (error) {
        reject(false);
      } else {
        resolve(result);
      }
    });
  });
};

module.exports.createEmployeeDBService = (employeeDetails) => {
  return new Promise(function myFn(resolve, reject) {
    var employeeModel = new employeeModel();

    employeeModel.name = employeeDetails.name;
    employeeModel.address = employeeDetails.address;
    employeeModel.phone = employeeDetails.phone;
    employeeModel.save(function resultHandle(error, result) {
      if (error) {
        reject(false);
      } else {
        resolve(true);
      }
    });
  });
};
module.exports.updateEmployeeDBService = (id, employeeDetails) => {
  console.log(employeeDetails);
  return new Promise(function myFn(resolve, reject) {
    employeeModel.findByIdAndUpdate(
      id,
      employeeDetails,
      function returnData(error, result) {
        if (error) {
          reject(false);
        } else {
          resolve(result);
        }
      }
    );
  });
};
module.exports.removeEmployeeDBService = (id) => {
  return new Promise(function myFn(resolve, reject) {
    employeeModel.findByIdAndDelete(id, function returnData(error, result) {
      if (error) {
        reject(false);
      } else {
        resolve(result);
      }
    });
  });
};
