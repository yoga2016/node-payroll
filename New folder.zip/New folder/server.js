var express = require("express");
var server = express();
var routes = require("./routes/routes");
var mongoose = require("mongoose");
var port = 6000;

mongoose.set("strictQuery", true);
mongoose.connect(
  "mongodb://127.0.0.1:27017/dbpayroll",
  { useNewUrlParser: true, useUnifiedTopology: true },
  function checkKB(error) {
    if (error) {
      console.log(error);
    } else {
      console.log("DB Connected!!!!!");
    }
  }
);

server.use(express.json());
server.use(routes);

server.listen(port, () => {
  if (error) {
    console.log(`error connection`);
  } else {
    console.log(`connection port ${port}`);
  }
});
