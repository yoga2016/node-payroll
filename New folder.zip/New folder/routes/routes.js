const express = require("express");
const router = express.Router();
var employeeController = require("../src/employee/employeeController");

router.route("/employee/getAll").get(employeeController.getDataConntrollerfn);
// router
//   .route("/employee/create")
//   .get(employeeController.createEmployeeControllerfn);

// router
//   .route("/employee/update/:id")
//   .patch(employeeController.updateEmployeeController);
// router
//   .route("/employee/delete/:id")
//   .delete(employeeController.deleteEmployeeController);
module.exports = router;
